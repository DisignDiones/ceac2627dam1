DROP TABLE clientes;

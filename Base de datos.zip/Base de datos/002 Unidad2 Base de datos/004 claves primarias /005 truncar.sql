truncate clientes;

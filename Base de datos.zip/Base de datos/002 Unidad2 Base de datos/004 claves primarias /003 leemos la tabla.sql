SELECT * FROM Clientes;
